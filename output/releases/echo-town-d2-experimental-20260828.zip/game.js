(function () {
  "use strict";

  const STORAGE_KEY = "echo-town-save";
  const SAVE_VERSION = 2;
  const MAX_STAGES = 8;
  const MAX_SAVE_BYTES = 512 * 1024;
  const MAX_HISTORY = 20;
  const MAX_TEXT_LENGTH = 240;
  const MAX_STAT = { health: 3, coins: 6, courage: 5, bond: 6 };

  const TOWN_LABELS = {
    bridge: { label: "河桥", values: ["桥板缺了三块", "有人开始补桥", "桥面重新亮灯"] },
    river: { label: "河水", values: ["浑浊，带着铁锈味", "水闸有人照看", "清亮得能看见石头"] },
    trust: { label: "邻里", values: ["各自关门", "开始互相留灯", "愿意替彼此守夜"] },
    archive: { label: "镇志", values: ["旧账本无人翻", "多了一页手写记录", "终于有了自己的名字"] }
  };

  const DEFAULT_STATE = {
    version: SAVE_VERSION,
    world: {
      completedLives: 0,
      bridge: 0,
      river: 0,
      trust: 0,
      archive: 0,
      relics: [],
      echoes: [],
      history: [],
      lastEcho: "河水从镇子中间穿过去，谁也没有想过它会记得什么。"
    },
    settings: { fontScale: "normal" },
    currentLife: null,
    screen: "start"
  };

  let state = loadState();
  let toastTimer = null;

  const $ = (selector) => document.querySelector(selector);

  function isRecord(value) {
    return Boolean(value) && typeof value === "object" && !Array.isArray(value);
  }

  function safeText(value, limit = MAX_TEXT_LENGTH) {
    return typeof value === "string" ? value.slice(0, limit) : "";
  }

  function safeStringList(value, limit) {
    if (!Array.isArray(value)) return [];
    return [...new Set(value.filter((item) => typeof item === "string").map((item) => safeText(item)))].slice(-limit);
  }

  function clampInteger(value, min, max, fallback = min) {
    const parsed = Number(value);
    if (!Number.isFinite(parsed)) return fallback;
    return Math.max(min, Math.min(max, Math.trunc(parsed)));
  }

  function escapeHtml(value) {
    return safeText(value).replace(/[&<>"']/g, (character) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    }[character]));
  }

  function isSavePayload(value) {
    return isRecord(value)
      && [1, SAVE_VERSION].includes(Number(value.version))
      && isRecord(value.world)
      && (value.currentLife == null || isRecord(value.currentLife));
  }

  function normalizeHistory(value) {
    if (!Array.isArray(value)) return [];
    return value.map((entry) => {
      if (!isRecord(entry)) return null;
      const town = Array.isArray(entry.town) ? entry.town.filter(isRecord).slice(0, 8).map((item) => ({
        key: safeText(item.key, 40),
        label: safeText(item.label, 40),
        value: safeText(item.value, 80),
        changed: Boolean(item.changed)
      })) : [];
      return {
        generation: clampInteger(entry.generation, 1, 9999, 1),
        choices: safeStringList(entry.choices, MAX_STAGES),
        echoes: safeStringList(entry.echoes, MAX_STAGES),
        relics: safeStringList(entry.relics, 20),
        town,
        verdict: safeText(entry.verdict) || "小镇从那里继续。"
      };
    }).filter(Boolean).slice(-MAX_HISTORY);
  }

  function cloneDefault() {
    return JSON.parse(JSON.stringify(DEFAULT_STATE));
  }

  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY) || localStorage.getItem("echo-town-mvp-v1");
      const saved = raw ? JSON.parse(raw) : null;
      if (!isSavePayload(saved)) return cloneDefault();
      return normalizeState(saved);
    } catch (error) {
      return cloneDefault();
    }
  }

  function normalizeState(saved) {
    const fresh = cloneDefault();
    const savedWorld = isRecord(saved.world) ? saved.world : {};
    const world = { ...fresh.world, ...savedWorld };
    world.completedLives = clampInteger(savedWorld.completedLives, 0, 9999, 0);
    ["bridge", "river", "trust", "archive"].forEach((key) => {
      world[key] = clampInteger(savedWorld[key], 0, 2, 0);
    });
    world.relics = safeStringList(savedWorld.relics, 20);
    world.echoes = safeStringList(savedWorld.echoes, 120);
    world.history = normalizeHistory(savedWorld.history);
    world.lastEcho = safeText(savedWorld.lastEcho) || fresh.world.lastEcho;
    const savedLife = isRecord(saved.currentLife) ? saved.currentLife : null;
    const savedStats = savedLife && isRecord(savedLife.stats) ? savedLife.stats : {};
    const currentLife = savedLife ? {
      generation: clampInteger(savedLife.generation, 1, 9999, world.completedLives + 1),
      stage: clampInteger(savedLife.stage, 0, MAX_STAGES - 1, 0),
      stats: {
        health: clampInteger(savedStats.health, 0, MAX_STAT.health, 3),
        coins: clampInteger(savedStats.coins, 0, MAX_STAT.coins, 2),
        courage: clampInteger(savedStats.courage, 0, MAX_STAT.courage, 1),
        bond: clampInteger(savedStats.bond, 0, MAX_STAT.bond, 0)
      },
      choices: safeStringList(savedLife.choices, MAX_STAGES),
      choiceLabels: safeStringList(savedLife.choiceLabels, MAX_STAGES),
      echoes: safeStringList(savedLife.echoes, MAX_STAGES),
      relics: safeStringList(savedLife.relics, 20),
      status: savedLife.status === "complete" ? "complete" : "active",
      lastFeedback: safeText(savedLife.lastFeedback)
    } : null;
    let screen = ["start", "game", "ending", "archive"].includes(saved.screen) ? saved.screen : "start";
    if ((screen === "game" || screen === "ending") && !currentLife) screen = "start";
    if (screen === "archive" && !world.history.length) screen = "start";
    return { ...fresh, ...saved, version: SAVE_VERSION, screen, world, settings: { ...fresh.settings, ...(saved.settings || {}) }, currentLife };
  }

  function persist(message) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      $("#save-status").textContent = "已保存到本地";
      if (message) showToast(message);
      return true;
    } catch (error) {
      $("#save-status").textContent = "仅保留在当前页面";
      showToast("本地存档暂不可用，当前页面仍可继续");
      return false;
    }
  }

  function clearStoredSaves() {
    try {
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem("echo-town-mvp-v1");
      return true;
    } catch (error) {
      return false;
    }
  }

  function showToast(message) {
    const toast = $("#toast");
    toast.textContent = message;
    toast.classList.add("is-visible");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("is-visible"), 1800);
  }

  function exportSave() {
    try {
      const payload = JSON.stringify({ ...state, exportedAt: new Date().toISOString() }, null, 2);
      const blob = new Blob([payload], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "echo-town-save.json";
      link.click();
      URL.revokeObjectURL(url);
      showToast("存档已导出");
    } catch (error) {
      showToast("当前浏览器不支持导出存档");
    }
  }

  function importSave(file) {
    if (!file) return;
    if (Number(file.size) > MAX_SAVE_BYTES) {
      showToast("存档文件过大，未做修改");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const imported = JSON.parse(reader.result);
        if (!isSavePayload(imported)) throw new Error("invalid save");
        const nextState = normalizeState(imported);
        state = nextState;
        persist("存档已导入");
        render();
      } catch (error) {
        showToast("存档格式不正确，未做修改");
      }
    };
    reader.onerror = () => showToast("存档读取失败，未做修改");
    reader.readAsText(file);
  }

  function createLife() {
    return {
      generation: state.world.completedLives + 1,
      stage: 0,
      stats: { health: 3, coins: 2, courage: 1, bond: 0 },
      choices: [],
      choiceLabels: [],
      echoes: [],
      relics: [],
      status: "active"
    };
  }

  function getTownText(key) {
    const town = TOWN_LABELS[key];
    return town.values[Math.max(0, Math.min(2, Number(state.world[key]) || 0))];
  }

  function townSnapshot() {
    return Object.keys(TOWN_LABELS).map((key) => ({
      key,
      label: TOWN_LABELS[key].label,
      value: getTownText(key),
      changed: Number(state.world[key]) > 0
    }));
  }

  function choice(id, label, detail, impact, apply, feedback) {
    return { id, label, detail, impact, apply, feedback };
  }

  function getEvents() {
    const bridgeOpen = state.world.bridge > 0;
    const riverWatched = state.world.river > 0;
    const hasKey = state.world.relics.includes("铜钥匙");

    return [
      {
        age: "7岁",
        place: "南岸·河边",
        chapter: "第一章 · 风筝",
        title: "河对岸有个孩子，捡到了你的风筝。",
        copy: bridgeOpen
          ? "桥面还留着上一代人补过的钉子。那孩子站在对岸，手里攥着风筝线，喊你的名字——你明明从没见过他。"
          : "桥板缺了一角。河水把风筝线拖得笔直，另一个孩子站在对岸，等你决定要不要过去。",
        choices: [
          choice("kite-share", "把风筝线分给他一半", "你们得一起拉住它。", "+牵挂  +信任", (life) => { life.stats.bond += 1; state.world.trust += 1; life.echoes.push("有人记住了你愿意分一半风筝线。"); }, "你们把风筝收回来时，线已经缠成一团。那个孩子说，他叫阿禾。后来他总会替你留一盏灯。"),
          choice("kite-sell", "把风筝卖给杂货铺", "有钱就能买新的，也能买一顿热饭。", "+积蓄  +1", (life) => { life.stats.coins += 1; life.echoes.push("杂货铺的铜铃记住了你的第一笔买卖。"); }, "杂货铺多了一枚铜铃。你拿到钱，却发现阿禾已经一个人把风筝捡回来了。"),
          choice("kite-cross", "踩着剩下的桥板过去", "桥在晃，河水在涨。", "−身体  +胆量", (life) => { life.stats.health -= 1; life.stats.courage += 1; state.world.bridge += 1; life.echoes.push("你踩过了那块没人敢踩的桥板。"); }, "你在水里摔了一跤，还是把风筝递了过去。阿禾没有道谢，只是把你拉上岸。")
        ]
      },
      {
        age: "12岁",
        place: "北街·空教室",
        chapter: "第二章 · 借来的书",
        title: "停课的那天，老师把镇志的钥匙交给了你。",
        copy: state.world.archive > 0
          ? "你已经知道镇志不是一本书，而是一种把人留在原地的办法。老师说，北街的孩子们需要有人读给他们听。"
          : "窗外有人在搬走课桌。老师把一把旧钥匙放进你手里，说里面的名字比课本更容易被忘掉。",
        choices: [
          choice("school-read", "把镇志读给留下的孩子听", "一页不一定能改变什么，但能让一个名字多活一天。", "+镇志  +牵挂", (life) => { state.world.archive += 1; life.stats.bond += 1; life.echoes.push("空教室里有人听完了一页镇志。"); }, "你读得很慢。读到最后，孩子们已经记住了那条被涂黑的支流。"),
          choice("school-leave", "用钥匙打开后门，去外地读书", "你想知道镇外的河是不是也这样记事。", "+胆量  −牵挂", (life) => { life.stats.courage += 1; life.stats.bond -= 1; life.echoes.push("一把钥匙换来了一张离镇的车票。"); }, "你确实去了外地。多年后回来时，镇上的人还记得你借走的那本书。"),
          choice("school-sell", "把钥匙卖给收废品的人", "家里缺煤，明天也要吃饭。", "+积蓄  −镇志", (life) => { life.stats.coins += 1; state.world.trust += 1; life.echoes.push("旧钥匙没有进镇志，进了收废站。"); }, "钥匙的价钱只够买几天煤。你没有后悔，只是后来再也没人打开那扇门。")
        ]
      },
      {
        age: "16岁",
        place: "桥脚·旧仓房",
        chapter: "第二章 · 秘密",
        title: "阿禾说，桥墩里藏着一页不该消失的账。",
        copy: riverWatched
          ? "巡河的人已经把水位线刻在石头上。阿禾把一张发潮的纸塞给你：上面写着有人把上游的闸门卖过一次。"
          : "水位线比去年高了一掌。纸页发潮，墨水像被人用手指抹过，只有一个日期还认得出来。",
        choices: [
          choice("secret-keep", "先替阿禾把账藏好", "信任不是证据，但能让证据活得久一点。", "+牵挂  +胆量", (life) => { life.stats.bond += 1; life.stats.courage += 1; state.world.archive += 1; life.echoes.push("一页湿账被藏在砖缝里。"); }, "你把账藏进桥墩，和阿禾约好十年后再看。秘密没有消失，只是多等了一会儿。"),
          choice("secret-report", "把账交给巡河队", "让大人们先知道水闸的事。", "+镇志  −牵挂", (life) => { state.world.river += 1; state.world.archive += 1; life.stats.bond -= 1; life.echoes.push("巡河队第一次认真看了上游的水闸。"); }, "巡河队封了闸，却没有问账从哪里来。阿禾从那天起不再叫你的名字。"),
          choice("secret-burn", "烧掉它，劝阿禾离开镇子", "有些证据只会让留下的人更危险。", "+胆量  −积蓄", (life) => { life.stats.courage += 1; life.stats.coins -= 1; state.world.trust += 1; life.echoes.push("一页账化成灰，换来一张去外地的车票。"); }, "纸烧得很快。阿禾走了，镇上的人开始在夜里互相留灯——没人说原因。")
        ]
      },
      {
        age: "28岁",
        place: "东街·修理铺",
        chapter: "第三章 · 钉子",
        title: "雨季又到了，镇上需要有人把桥修好。",
        copy: hasKey
          ? "你从上一世留下的旧盒子里摸到一把铜钥匙。它打开修理铺后门，也打开祁叔留下的工具柜。"
          : "祁叔把一串生锈的工具放在桌上，说修桥不难，难的是修好以后还要有人愿意走过去。",
        choices: [
          choice("bridge-fund", "拿出积蓄，先把桥面补起来", "今天少吃一顿，明天就多一条路。", "−积蓄  +河桥", (life) => { life.stats.coins -= 2; state.world.bridge += 1; state.world.trust += 1; life.echoes.push("桥面多了三块新木板。"); }, "新木板有松木的气味。第一位过桥的人不是镇长，是一个拎着菜篮子的老人。"),
          choice("bridge-shop", "开一间修理铺，慢慢攒钱", "留下来的人，先要有地方修好自己的东西。", "+积蓄  +镇志", (life) => { life.stats.coins += 1; state.world.archive += 1; if (!state.world.relics.includes("铜钥匙")) state.world.relics.push("铜钥匙"); life.echoes.push("修理铺的门口挂上了铜钥匙。"); }, "你没有立刻修桥，但东街开始有了一个会亮灯的窗口。人们拿坏掉的钟来，也拿没说完的话来。"),
          choice("bridge-map", "把旧地图交给镇公所", "先搞清楚谁在桥下、谁在上游。", "+胆量  +河水", (life) => { life.stats.courage += 1; state.world.river += 1; state.world.archive += 1; life.echoes.push("一张旧地图被钉进镇公所的墙。"); }, "地图上有一条被涂黑的支流。镇公所第一次承认，水不是从天上凭空来的。")
        ]
      },
      {
        age: "36岁",
        place: "东街·修理铺",
        chapter: "第五章 · 接手",
        title: "修理铺的灯每天比你早醒。",
        copy: state.world.trust > 1
          ? "来找你的人越来越多。他们不只带来坏掉的钟，也带来关于上游和桥的不同说法。"
          : "你把门推开，灰尘落在柜台上。祁叔留下的工具还能用，只是没有人告诉你该修什么。",
        choices: [
          choice("shop-teach", "把工具交给一个年轻人", "会修东西的人不该只有一个。", "+信任  +牵挂", (life) => { state.world.trust += 1; life.stats.bond += 1; life.echoes.push("修理铺有了第二双会用工具的手。"); }, "他学会了先问清楚再动手。很多年后，他会把这句话写进给孩子的作业本。"),
          choice("shop-river", "关门三天，去上游看水位", "修理铺可以晚开，河水不会等人。", "−积蓄  +河水", (life) => { life.stats.coins -= 1; state.world.river += 1; life.echoes.push("修理铺熄灯三天，河水多了一条记录。"); }, "你在上游看见闸门上的新锁。回来时，门口有人等着修一只停住的钟。"),
          choice("shop-record", "把每一件来修的东西记进镇志", "物件比传闻更会说实话。", "+镇志  −积蓄", (life) => { state.world.archive += 1; life.stats.coins -= 1; life.echoes.push("修理铺的物件开始有了编号。"); }, "你给每一件东西编号，给每一个来的人留一行空白。镇志因此变得越来越像一个家。")
        ]
      },
      {
        age: "45岁",
        place: "南岸·暴雨夜",
        chapter: "第四章 · 水位",
        title: "暴雨把仓房的门顶住了，里面还有人。",
        copy: bridgeOpen
          ? "桥面在雨里发白。你听见对岸有人敲门，镇上的人已经在广场集合，却没人知道该先救谁。"
          : "水漫过第一块石阶。你手里只有一盏灯，身后是挤在一起的邻居，前面是越来越响的河。",
        choices: [
          choice("flood-ledger", "先救出仓房里的账本", "一页页纸，记着许多人的名字。", "−身体  +镇志", (life) => { life.stats.health -= 1; state.world.archive += 1; life.echoes.push("被水泡软的账本保住了名字。"); }, "你抱着账本游回来。有人嫌你傻，但第二天每一户人家都来问：我的名字还在吗？"),
          choice("flood-people", "挨家挨户敲门，先把人带到高处", "今晚的记录可以没有，活人不能没有。", "−身体  +信任", (life) => { life.stats.health -= 1; state.world.trust += 2; life.echoes.push("那一夜，镇上每扇门都被敲响。"); }, "你敲到最后一扇门时，阿禾的后人把灯递给你。那盏灯一直亮到天亮。"),
          choice("flood-gate", hasKey ? "用铜钥匙打开旧水闸" : "沿着地图去找旧水闸", hasKey ? "钥匙转动时，整座镇子都在听。" : "也许地图没有骗你。", "−胆量  +河水", (life) => { life.stats.courage -= 1; state.world.river += 1; state.world.bridge += 1; life.echoes.push("旧水闸被重新打开，河水终于退了。"); }, hasKey ? "铜钥匙卡了一下，闸门还是开了。河水退去时，桥下露出一行刻字：别把名字忘了。" : "你没有找到钥匙，只找到了开闸的办法。河水退去一些，镇上的人第一次看见桥墩底下的刻字。")
        ]
      },
      {
        age: "52岁",
        place: "镇公所·后室",
        chapter: "第六章 · 账页",
        title: "雨季过后，账本在水痕里翻到最后一页。",
        copy: state.world.archive > 1
          ? "名字、日期、闸门和桥都已经有了记录。没有人愿意承认自己在旧账里，但所有人都来问下一页写什么。"
          : "账本的边角粘在一起。你辨认出一个熟悉的日期，也辨认出有人把它撕掉了一半。",
        choices: [
          choice("ledger-open", "把账页贴回去，公开念完", "让镇上的人听见自己的名字。", "+镇志  +信任", (life) => { state.world.archive += 1; state.world.trust += 1; life.echoes.push("最后一页账被贴回了镇志。"); }, "有人中途离开，有人留下来听。念完以后，镇公所的窗第一次没有关上。"),
          choice("ledger-protect", "把最危险的名字留在自己手里", "有些真相需要一个人先替它活着。", "+胆量  +遗物", (life) => { life.stats.courage += 1; if (!state.world.relics.includes("湿账页")) state.world.relics.push("湿账页"); life.echoes.push("一张湿账页被你收进旧盒子。"); }, "你没有公开那几个名字。旧盒子被放在修理铺最里面，等下一双手判断该不该打开。"),
          choice("ledger-trade", "拿账页换一批修桥木料", "如果路能走通，迟早会有人问起路从哪里来。", "+河桥  −镇志", (life) => { state.world.bridge += 1; life.stats.coins += 1; life.echoes.push("一页账换来一车桥木。"); }, "木料先到了。那一页账没有消失，只是被你藏进了桥下更干燥的地方。")
        ]
      },
      {
        age: "67岁",
        place: "广场·晚钟",
        chapter: "第五章 · 名字",
        title: "钟响了。你终于知道该把哪一件事交给下一世。",
        copy: state.world.archive > 1
          ? "镇志已经摞到窗边。有人把你小时候的风筝画在最后一页，墨迹旁边写着阿禾的名字。"
          : "广场的钟慢了半拍。镇上的人等着你说点什么，但这一生真正重要的事，从来没有一句合适的总结。",
        choices: [
          choice("bell-name", "在广场讲出那年的名字", "让一件事从秘密变成共同记忆。", "+镇志  +牵挂", (life) => { state.world.archive += 1; life.stats.bond += 1; state.world.trust += 1; life.echoes.push("阿禾的名字被写进晚钟声里。"); }, "你只说了一个名字：阿禾。镇上的人没有鼓掌，但第二天，桥边多了一块新的木牌。"),
          choice("bell-key", "把铜钥匙交给一个孩子", "工具总要有下一双手来接。", "+河桥  +遗物", (life) => { if (!state.world.relics.includes("铜钥匙")) state.world.relics.push("铜钥匙"); state.world.bridge += 1; life.echoes.push("铜钥匙交到一个孩子手里。"); }, "孩子问它能开什么。你说，先拿去开一扇卡住的门。至于门后是什么，等他自己长大。"),
          choice("bell-walk", "独自再走一次桥", "不解释，也不回头。", "+胆量  +河桥", (life) => { life.stats.courage += 1; state.world.bridge += 1; life.echoes.push("你最后一次走过了桥。"); }, "桥还是会晃，但每一块木板都认得你的脚。你走到对岸时，河水正好把月亮还给了镇子。")
        ]
      }
    ];
  }

  function clamp(value, min, max) {
    return clampInteger(value, min, max, min);
  }

  function applyChoice(index) {
    const life = state.currentLife;
    const event = getEvents()[life.stage];
    const selected = event.choices[index];
    if (!selected || life.choices.length > life.stage) return;
    selected.apply(life);
    life.stats.health = clamp(life.stats.health, 0, MAX_STAT.health);
    life.stats.coins = clamp(life.stats.coins, 0, MAX_STAT.coins);
    life.stats.courage = clamp(life.stats.courage, 0, MAX_STAT.courage);
    life.stats.bond = clamp(life.stats.bond, 0, MAX_STAT.bond);
    life.choices.push(selected.id);
    life.choiceLabels.push(selected.label);
    life.lastFeedback = selected.feedback;
    persist("这一页已保存");
    renderGame(true);
    setTimeout(() => $("[data-action='next-stage']")?.focus(), 30);
  }

  function startLife() {
    state.currentLife = createLife();
    state.screen = "game";
    persist("第一世开始了");
    render();
    setTimeout(() => $("[data-choice]")?.focus(), 30);
  }

  function goToNextStage() {
    const life = state.currentLife;
    if (!life || life.choices.length <= life.stage) return;
    if (life.stage >= MAX_STAGES - 1) {
      finishLife();
      return;
    }
    life.stage += 1;
    persist();
    renderGame(false);
    setTimeout(() => $("[data-choice]")?.focus(), 30);
  }

  function finishLife() {
    const life = state.currentLife;
    if (!life || life.status === "complete") return;
    life.status = "complete";
    state.world.completedLives += 1;
    const verdict = getVerdict(life.stats);
    const finalEcho = life.echoes[life.echoes.length - 1] || "你没有留下物件，但留下了一个可以被重新问起的问题。";
    state.world.echoes = [...state.world.echoes, ...life.echoes].slice(-12);
    state.world.lastEcho = finalEcho;
    state.world.history = [...(state.world.history || []), {
      generation: life.generation,
      choices: [...(life.choiceLabels || [])],
      echoes: [...life.echoes].slice(-5),
      relics: [...new Set([...(state.world.relics || []), ...(life.relics || [])])],
      town: townSnapshot(),
      verdict
    }].slice(-20);
    state.screen = "ending";
    persist("这一生已封存");
    render();
    setTimeout(() => $("[data-action='next-life']")?.focus(), 30);
  }

  function render() {
    $("#screen-start").classList.toggle("is-hidden", state.screen !== "start");
    $("#screen-game").classList.toggle("is-hidden", state.screen !== "game");
    $("#screen-ending").classList.toggle("is-hidden", state.screen !== "ending");
    $("#screen-archive").classList.toggle("is-hidden", state.screen !== "archive");
    renderStart();
    if (state.screen === "game") renderGame(Boolean(state.currentLife && state.currentLife.choices.length > state.currentLife.stage));
    if (state.screen === "ending") renderEnding();
    if (state.screen === "archive") renderArchive();
  }

  function renderStart() {
    const hasActive = state.currentLife?.status === "active";
    $("[data-action='start-life']").textContent = state.world.completedLives ? "再开一世 →" : "开始第一世 →";
    $("[data-action='continue-life']").classList.toggle("is-hidden", !hasActive);
    $("#generation-label").textContent = state.world.completedLives ? `已经走过 ${state.world.completedLives} 世` : "还没有人写下第一行";
    $("#start-echo").textContent = state.world.lastEcho;
    $("#start-town").innerHTML = townSnapshot().slice(0, 3).map((item) => `<div class="town-mini-item"><span>${item.label}</span><strong>${item.value}</strong></div>`).join("");
    $("[data-action='view-archive']").classList.toggle("is-hidden", !(state.world.history || []).length);
  }

  function renderGame(hasFeedback) {
    const life = state.currentLife;
    const event = getEvents()[life.stage];
    const feedbackVisible = hasFeedback || life.choices.length > life.stage;
    $("#life-label").textContent = `第 ${life.generation} 世`;
    $("#stage-label").textContent = event.chapter;
    $("#event-age").textContent = event.age;
    $("#event-place").textContent = event.place;
    $("#event-title").textContent = event.title;
    $("#event-copy").textContent = event.copy;
    const progress = $("#life-progress");
    progress.setAttribute("aria-valuenow", String(life.stage + 1));
    progress.innerHTML = Array.from({ length: MAX_STAGES }, (_, index) => `<span class="${index < life.stage ? "is-done" : ""} ${index === life.stage ? "is-current" : ""}"></span>`).join("");
    const legacy = $("#legacy-banner");
    const hasLegacy = life.generation > 1;
    legacy.classList.toggle("is-hidden", !hasLegacy);
    if (hasLegacy) legacy.textContent = `上一世留下的东西正在这里起作用：${state.world.lastEcho}`;
    $("#choices").innerHTML = event.choices.map((item, index) => `<button class="choice" type="button" data-choice="${index}" aria-label="${item.label}。${item.detail}" ${feedbackVisible ? "disabled" : ""}><span class="choice-key">${index + 1}</span><span class="choice-copy"><span class="choice-label">${item.label}</span><span class="choice-detail">${item.detail}</span></span><span class="choice-impact">${item.impact}</span></button>`).join("");
    $("#feedback").classList.toggle("is-hidden", !feedbackVisible);
    if (feedbackVisible) {
      $("#feedback-copy").textContent = life.lastFeedback;
      $("#feedback-changes").innerHTML = life.echoes.slice(-2).map((echo) => `<span class="change-chip">${escapeHtml(echo)}</span>`).join("");
      $("[data-action='next-stage']").textContent = life.stage >= MAX_STAGES - 1 ? "封存这一生 →" : "翻到下一页 →";
    }
    renderStats(life);
    renderTown();
    renderRelics(life);
  }

  function renderStats(life) {
    $("#stat-health").textContent = `${life.stats.health} / ${MAX_STAT.health}`;
    $("#stat-coins").textContent = String(life.stats.coins);
    $("#stat-courage").textContent = String(life.stats.courage);
    $("#stat-bond").textContent = String(life.stats.bond);
    $("#meter-health").style.transform = `scaleX(${life.stats.health / MAX_STAT.health})`;
    $("#meter-coins").style.transform = `scaleX(${life.stats.coins / MAX_STAT.coins})`;
    $("#meter-courage").style.transform = `scaleX(${life.stats.courage / MAX_STAT.courage})`;
    $("#meter-bond").style.transform = `scaleX(${life.stats.bond / MAX_STAT.bond})`;
  }

  function renderTown() {
    $("#town-year").textContent = state.world.completedLives ? `第 ${state.world.completedLives} 世后` : "第一行还没写下";
    $("#town-state").innerHTML = townSnapshot().map((item) => `<div class="town-state-row"><span>${item.label}</span><strong class="${item.changed ? "is-changed" : ""}">${item.value}</strong></div>`).join("");
  }

  function renderRelics(life) {
    const relics = [...new Set([...(state.world.relics || []), ...(life.relics || [])])];
    $("#relic-count").textContent = `${relics.length} 件`;
    $("#relics").innerHTML = relics.length ? relics.map((relic) => `<span class="relic">${escapeHtml(relic)}</span>`).join("") : `<span class="relic-empty">这一世还没有可交给下一世的物件。</span>`;
  }

  function renderEnding() {
    const life = state.currentLife;
    $("#ending-copy").textContent = `这是你的第 ${life.generation} 世。你在 67 岁这天把最后一页交还给了回声镇，下一世会从这里开始。`;
    $("#ending-stats").innerHTML = `<div class="ending-stat"><strong>${life.stats.bond}</strong><span>牵挂</span></div><div class="ending-stat"><strong>${life.stats.courage}</strong><span>胆量</span></div><div class="ending-stat"><strong>${life.echoes.length}</strong><span>留下的回声</span></div>`;
    $("#ending-verdict").textContent = getVerdict(life.stats);
    const echoes = life.echoes.length ? life.echoes.slice(-5) : ["你没有留下物件，但留下了一个可以被重新问起的问题。"];
    $("#echo-list").innerHTML = echoes.map((echo) => `<div class="echo-item"><span class="echo-mark" aria-hidden="true">✦</span><span>${escapeHtml(echo)}</span></div>`).join("");
  }

  function getVerdict(stats) {
    return stats.bond >= 3 ? "你没有改变所有事情，但有人会因为记得你，而愿意再往前走一步。" : stats.courage >= 3 ? "你把害怕的事做完了一部分。剩下的，交给下一世的人。" : "你这一生没有轰轰烈烈，却把一件小事做到了最后。小镇会从那里继续。";
  }

  function renderArchive() {
    const history = [...(state.world.history || [])].reverse();
    $("#archive-life-count").textContent = `${state.world.completedLives} 世`;
    $("#archive-town").innerHTML = townSnapshot().map((item) => `<div class="town-state-row"><span>${item.label}</span><strong class="${item.changed ? "is-changed" : ""}">${item.value}</strong></div>`).join("");
    $("#archive-timeline").innerHTML = history.length ? history.map((entry) => {
      const choices = (entry.choices || []).slice(0, 3).map((item) => `<span class="archive-entry-tag">${escapeHtml(item)}</span>`).join("");
      const echo = escapeHtml((entry.echoes || ["这一世没有留下可复述的回声。"]).slice(-1)[0]);
      const verdict = escapeHtml(entry.verdict || "小镇从那里继续。");
      return `<article class="archive-entry"><div class="archive-entry-number">第 ${entry.generation} 世</div><div><h2>${echo}</h2><p>${verdict}</p></div><div class="archive-entry-tags">${choices}</div></article>`;
    }).join("") : `<p class="archive-empty">还没有完整的一生。先走到最后一页，镇志才会开始长出时间。</p>`;
  }

  function handleAction(action) {
    if (action === "start-life") {
      const hasActiveLife = state.currentLife?.status === "active";
      if (hasActiveLife && !window.confirm("当前人生还没有封存，开启新一世会放弃这一页进度。确定吗？")) return;
      startLife();
    }
    if (action === "continue-life") { state.screen = "game"; render(); }
    if (action === "next-stage") goToNextStage();
    if (action === "next-life") startLife();
    if (action === "home") { state.screen = "start"; persist(); render(); }
    if (action === "view-archive") { state.screen = "archive"; render(); }
    if (action === "export-save") exportSave();
    if (action === "erase-save") {
      if (window.confirm("确定清除所有人生和小镇记忆吗？此操作无法撤销。")) {
        const cleared = clearStoredSaves();
        state = cloneDefault();
        render();
        showToast(cleared ? "镇志已回到空白页" : "浏览器未允许清除本地存档");
      }
    }
  }

  document.addEventListener("click", (event) => {
    const actionElement = event.target.closest("[data-action]");
    if (actionElement) handleAction(actionElement.dataset.action);
    const choiceElement = event.target.closest("[data-choice]");
    if (choiceElement) applyChoice(Number(choiceElement.dataset.choice));
  });

  document.addEventListener("keydown", (event) => {
    if (state.screen !== "game" || state.currentLife?.choices.length > state.currentLife?.stage) return;
    const index = Number(event.key) - 1;
    if (index >= 0 && index < 3) applyChoice(index);
  });

  $("#import-input").addEventListener("change", (event) => {
    importSave(event.target.files[0]);
    event.target.value = "";
  });

  window.addEventListener("beforeunload", () => {
    if (state.currentLife?.status === "active") persist();
  });

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("sw.js").catch(() => {});
  }

  render();
})();
