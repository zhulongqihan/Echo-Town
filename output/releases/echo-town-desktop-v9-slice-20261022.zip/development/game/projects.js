(function (global) {
  "use strict";

  const CONTENT = global.EchoTownContent;
  if (!CONTENT) throw new Error("projects.js requires content.js");
  const ID = "craft-customers-youth-v1";
  const JOB_ID = "project-craft-shift";
  const START = CONTENT.rounds.findIndex(round => round.id === "youth-departure");
  const PREPARE = CONTENT.rounds.findIndex(round => round.id === "youth-mentor");
  const RETURN = CONTENT.rounds.findIndex(round => round.id === "youth-love");
  const DEADLINE = CONTENT.rounds.findIndex(round => round.id === "youth-career");
  const STATUS = ["active", "completed", "incomplete", "withdrawn"];
  const STEPS = ["firstWork", "preparation", "returnWork"];
  const ROUNDS = { firstWork: START, preparation: PREPARE, returnWork: RETURN };
  const copy = value => JSON.parse(JSON.stringify(value));
  const recordObject = value => value && typeof value === "object" && !Array.isArray(value);
  const integer = (value, min, max) => Number.isInteger(value) && value >= min && value <= max;
  function demand(condition, message) { if (!condition) throw new Error("项目记录无效：" + message); }
  function empty(life) {
    const eligible = life && life.status === "active" && (life.round < START || (life.round === START && life.actionPoints === CONTENT.actionPointsPerRound && life.sideActionsUsed === 0 && !life.lastAction));
    return { version: 1, eligibleFromRound: eligible ? START : null, current: null };
  }
  function keysAre(value, allowed) { return Object.keys(value).every(key => allowed.includes(key)); }
  function evidenceFor(life, step, key) {
    if (step.type === "BUY_ITEM") return (life.inventory || []).includes("toolkit") && Boolean(life.ledger && life.ledger.entries.some(entry => entry.round === PREPARE && entry.kind === "purchase" && entry.id === "toolkit" && entry.money === -step.moneySpent));
    return Boolean(life.strategy && life.strategy.evidence.some(entry => entry.round === step.round && entry.kind === (key === "preparation" ? "life" : "job") && entry.id === step.actionId && entry.success === true));
  }
  function deadlineEvent(life) {
    const action = (life.actions || []).find(entry => entry.round === DEADLINE + 1 && entry.age === CONTENT.rounds[DEADLINE].age);
    if (!action || !(life.strategy && life.strategy.evidence || []).some(entry => entry.round === DEADLINE && entry.kind === "event" && entry.id === action.actionId)) return false;
    return life.round > DEADLINE || life.status === "complete" || (life.round === DEADLINE && life.lastAction && life.lastAction.actionId === action.actionId);
  }
  function result(projects, changed, message) { return { ok: true, changed: Boolean(changed), projects: copy(projects), message: message || "" }; }
  function refused(projects, message) { return { ok: false, changed: false, projects: copy(projects), message }; }

  // No repair/replay: absent data means the optional project has never started.
  // All present data must be valid. The save layer can call this before commit.
  function normalize(raw, life) {
    if (raw === undefined) return empty(life);
    demand(recordObject(raw) && raw.version === 1 && Object.prototype.hasOwnProperty.call(raw, "current") && keysAre(raw, ["version", "eligibleFromRound", "current"]), "版本或结构");
    demand(raw.eligibleFromRound === START || raw.eligibleFromRound === null, "接入起点");
    if (raw.current === null) return { version: 1, eligibleFromRound: raw.eligibleFromRound, current: null };
    const item = raw.current;
    demand(raw.eligibleFromRound === START, "项目不能早于接入起点");
    demand(recordObject(item) && item.id === ID && STATUS.includes(item.status) && keysAre(item, ["id", "status", "acceptedRound", "steps", "settledRound", "resultId", "finalCraft"]), "项目或状态");
    demand(item.acceptedRound === START, "接受节点");
    demand(recordObject(item.steps) && Object.keys(item.steps).every(key => STEPS.includes(key)), "步骤");
    const normalized = { id: ID, status: item.status, acceptedRound: START, steps: {} };
    const receipts = new Set();
    for (const key of STEPS) {
      const step = item.steps[key];
      if (step === undefined) continue;
      demand(recordObject(step) && step.round === ROUNDS[key] && keysAre(step, ["round", "type", "actionId", "slot", "receiptId", "ap", "moneySpent", "energySpent"]), key + "节点");
      const isPurchase = key === "preparation" && step.type === "BUY_ITEM" && step.actionId === "toolkit";
      const isPractice = key === "preparation" && step.type === "LIFE_ACTION" && step.actionId === "routine-repair";
      const isWork = key !== "preparation" && step.type === "LIFE_ACTION" && step.actionId === "shop-shift";
      demand(isPurchase || isPractice || isWork, key + "行动");
      demand(integer(step.slot, 1, CONTENT.actionPointsPerRound), key + "行动序号");
      if (isWork) demand(step.slot === 1, "两点工作必须是该节点第一次行动");
      const receiptId = [ID, step.round, step.slot, step.type, step.actionId].join(":");
      demand(step.receiptId === receiptId && !receipts.has(receiptId), key + "凭证");
      demand(step.ap === (key === "preparation" ? 1 : 2), key + "行动点");
      demand(integer(step.moneySpent, 0, Number.MAX_SAFE_INTEGER) && integer(step.energySpent, 0, Number.MAX_SAFE_INTEGER), key + "实际成本");
      if (isPurchase) demand(step.moneySpent === CONTENT.items.find(item => item.id === "toolkit").price && step.energySpent === 0, "工具价格");
      else demand(step.moneySpent === 0 && step.energySpent === 2, key + "精力成本");
      if (life) {
        demand(step.round <= life.round, "未来步骤");
        demand(evidenceFor(life, step, key), key + "缺少真实行动记录");
        if (step.round === life.round) demand(life.sideActionsUsed >= step.slot, key + "超过实际行动数");
      }
      receipts.add(receiptId);
      normalized.steps[key] = { round: step.round, type: step.type, actionId: step.actionId, slot: step.slot, receiptId, ap: step.ap, moneySpent: step.moneySpent, energySpent: step.energySpent };
    }
    if (life) {
      const currentSteps = Object.values(normalized.steps).filter(step => step.round === life.round);
      if (currentSteps.length) {
        const recordedAP = currentSteps.reduce((total, step) => total + step.ap, 0);
        const otherActions = Math.max(0, life.sideActionsUsed - currentSteps.length);
        demand(integer(life.actionPoints, 0, CONTENT.actionPointsPerRound - recordedAP - otherActions), "已记录步骤的行动点尚未实际扣除");
      }
    }
    if (item.status === "active") {
      demand(item.settledRound === undefined && item.resultId === undefined && item.finalCraft === undefined, "未结算项目不能有结果");
      if (life) demand(life.round >= START && life.round <= DEADLINE && life.status === "active", "活动项目时段");
    } else {
      demand(item.resultId === ID + ":" + item.status, "结果ID");
      demand(integer(item.settledRound, START, DEADLINE), "结算节点");
      if (item.status !== "withdrawn") demand(item.settledRound === DEADLINE, "期限结算");
      demand(Object.values(normalized.steps).every(step => step.round <= item.settledRound), "结算后步骤");
      if (life) demand(item.settledRound <= life.round, "未来结算");
      normalized.settledRound = item.settledRound;
      normalized.resultId = item.resultId;
      if (item.status !== "withdrawn") {
        demand(integer(item.finalCraft, 0, Number.MAX_SAFE_INTEGER), "结算时手艺");
        const complete = STEPS.every(key => normalized.steps[key]) && item.finalCraft >= 5;
        demand((item.status === "completed") === complete, "结果与真实步骤不符");
        normalized.finalCraft = item.finalCraft;
        if (life) demand(deadlineEvent(life), "尚未完成28岁人生事件");
      } else {
        demand(item.finalCraft === undefined, "退出不计算最终手艺");
      }
    }
    return { version: 1, eligibleFromRound: START, current: normalized };
  }

  function canAccept(life, projects) {
    if (!life || life.status !== "active") return "请先开始这一世";
    if (projects.current) return "这一世已经选择或结束过这个项目";
    if (projects.eligibleFromRound !== START) return "这一世已越过项目接入时点，下一世可以重新选择";
    if (life.round !== START || life.lastAction) return "在19岁安排生活前，可以选择这个青年项目";
    if (life.actionPoints !== CONTENT.actionPointsPerRound || life.sideActionsUsed !== 0) return "本节点已经安排过生活，项目从下一世重新选择";
    return "";
  }

  function accept(life, projectId) {
    const projects = normalize(life && life.projects, life);
    if (projectId !== undefined && projectId !== ID) return refused(projects, "没有这个项目");
    const reason = canAccept(life, projects);
    if (reason) return refused(projects, reason);
    projects.current = { id: ID, status: "active", acceptedRound: START, steps: {} };
    return result(projects, true, "开始建立固定客源。接受不消耗行动点，也不提供收入或成果。");
  }

  function withdraw(life) {
    const projects = normalize(life && life.projects, life);
    if (!projects.current || projects.current.status !== "active") return refused(projects, "没有正在进行的项目");
    projects.current.status = "withdrawn";
    projects.current.settledRound = life.round;
    projects.current.resultId = ID + ":withdrawn";
    return result(projects, true, "已退出建立客源。已赚工资、已付成本和物品照常保留，不返还准备时间；仍可继续普通帮工。");
  }

  // Called only after an existing command has paid AP/resources and recorded its
  // normal evidence. `before` is a private engine snapshot, never a UI payload.
  function record(life, receipt) {
    const projects = normalize(life && life.projects, life);
    const project = projects.current;
    if (!project || project.status !== "active" || !receipt) return result(projects, false);
    let key;
    if (receipt.type === "LIFE_ACTION" && receipt.id === "shop-shift" && life.round === START) key = "firstWork";
    if (receipt.type === "LIFE_ACTION" && receipt.id === "shop-shift" && life.round === RETURN) key = "returnWork";
    if (life.round === PREPARE && ((receipt.type === "LIFE_ACTION" && receipt.id === "routine-repair") || (receipt.type === "BUY_ITEM" && receipt.id === "toolkit"))) key = "preparation";
    if (!key || project.steps[key]) return result(projects, false);
    const before = receipt.before;
    if (!recordObject(before) || receipt.round !== life.round || life.lastAction || life.status !== "active") return refused(projects, "项目步骤缺少已执行行动凭证");
    const purchase = receipt.type === "BUY_ITEM";
    const source = purchase ? CONTENT.items.find(item => item.id === receipt.id) : CONTENT.jobs.concat(CONTENT.lifeActions).find(action => action.id === receipt.id);
    const ap = purchase ? 1 : Number(source.points || 1);
    const spent = { ap: before.actionPoints - life.actionPoints, money: Math.max(0, before.money - life.resources.money), energy: Math.max(0, before.energy - life.resources.energy) };
    const valid = integer(before.actionPoints, ap, CONTENT.actionPointsPerRound) && spent.ap === ap && integer(before.sideActionsUsed, 0, 1)
      && life.sideActionsUsed === before.sideActionsUsed + 1
      && spent.money === (purchase ? source.price : 0) && spent.energy === (purchase ? 0 : 2)
      && (purchase ? before.hadToolkit === false && life.inventory.includes("toolkit") : (life.strategy && life.strategy.evidence || []).some(entry => entry.round === life.round && entry.id === receipt.id && entry.success && entry.kind === (key === "preparation" ? "life" : "job")));
    if (!valid) return refused(projects, "项目只记录已经付出真实成本的行动");
    const slot = life.sideActionsUsed;
    project.steps[key] = { round: life.round, type: receipt.type, actionId: receipt.id, slot, receiptId: [ID, life.round, slot, receipt.type, receipt.id].join(":"), ap, moneySpent: spent.money, energySpent: spent.energy };
    return result(projects, true, key === "preparation" ? "准备已记录；练习和购买工具只需完成其中一次。" : key === "firstWork" ? "第一次真实服务已记录。21岁可以用一次练习或购买工具作准备。" : "回头客服务已记录。28岁处理完人生事件后检验这段积累。");
  }

  function settle(life) {
    const projects = normalize(life && life.projects, life);
    const project = projects.current;
    if (!project || project.status !== "active") return result(projects, false);
    if (life.round !== DEADLINE || !life.lastAction) return result(projects, false);
    const eventId = life.lastAction.actionId;
    if (!(life.strategy && life.strategy.evidence || []).some(entry => entry.round === DEADLINE && entry.kind === "event" && entry.id === eventId)) return refused(projects, "需要先完成28岁的人生事件");
    const completed = STEPS.every(key => project.steps[key]) && life.skills.craft >= 5;
    project.status = completed ? "completed" : "incomplete";
    project.settledRound = DEADLINE;
    project.resultId = ID + ":" + project.status;
    project.finalCraft = life.skills.craft;
    return result(projects, true, completed ? "固定客源已经形成。32岁起可选择固定客户维修；收入更高，也更耗精力、增加压力。此刻不额外发工资。" : "这次还没有形成固定客源。已经完成的工作、工资与准备保留，下一阶段仍可稳定帮工。");
  }

  function isUnlocked(life, projectId) {
    if (projectId && projectId !== ID) return false;
    const projects = normalize(life && life.projects, life);
    return Boolean(projects.current && projects.current.status === "completed");
  }

  function getJobDefinition() {
    return {
      id: JOB_ID, jobId: JOB_ID, label: "固定客户维修", minAge: 30, points: 2,
      detail: "独立安排熟客的维修，报酬稳定；交付和沟通都由自己承担。",
      cost: "2行动点 · 精力−4 · 压力+2", preview: "收入+14；基础不增加手艺或修理铺",
      requires: [{ type: "project", id: ID, label: "需要完成青年项目：建立固定客源" }, { type: "skill", key: "craft", min: 5, label: "需要手艺5" }],
      effect: { resources: { money: 14, energy: -4, pressure: 2 }, flags: ["worked-project-craft"] },
      tags: ["手艺", "独立接活", "精力取舍"],
    };
  }

  function getView(life) {
    if (!life) return null;
    const projects = normalize(life.projects, life);
    const project = projects.current;
    if (!project && life.round !== START) return null;
    const reason = canAccept(life, projects);
    const toolkit = CONTENT.items.find(item => item.id === "toolkit");
    const labels = { firstWork: "19岁完成一次修理铺帮工", preparation: "21岁练习手艺，或购买趁手工具", returnWork: "24岁再完成一次修理铺帮工" };
    const steps = STEPS.map(key => {
      const completed = Boolean(project && project.steps[key]);
      const requiredAP = key === "preparation" ? 1 : 2;
      const status = completed ? "completed" : life.round > ROUNDS[key] || (life.round === ROUNDS[key] && (life.lastAction || life.actionPoints < requiredAP)) ? "missed" : "pending";
      const detail = key === "preparation" ? "1行动点；练习耗2精力，购工具花12元，只记录一次准备" : "沿用修理铺帮工：2行动点、耗2精力、收入7";
      return { id: key, label: labels[key], age: CONTENT.rounds[ROUNDS[key]].age, status, completed, detail, receipt: completed ? copy(project.steps[key]) : null };
    });
    const prep = project && project.steps.preparation;
    const next = steps.find(step => step.status === "pending");
    const status = project ? project.status : reason ? "unavailable" : "available";
    const statusLabel = { active: "积累客源中", completed: "已建立固定客源", incomplete: "这次尚未形成客源", withdrawn: "已退出项目", available: "可以开始", unavailable: "本世不能接入" }[status];
    const outcomes = { completed: "32岁起解锁固定客户维修：2行动点，收入14、耗4精力、压力+2；基础不加手艺与修理铺。安排前记得给本节点的人生事件留出精力。", incomplete: "不解锁新工作；既有工资、物品和成长保留，不追加罚款。", withdrawn: "立即停止项目记录；已经支付的成本不返还，可继续普通工作。" };
    const remainingNodes = Math.max(0, DEADLINE - life.round + (life.lastAction ? 0 : 1));
    const canWithdraw = Boolean(project && project.status === "active");
    const completeCount = steps.filter(step => step.completed).length;
    const missed = steps.filter(step => step.status === "missed");
    const missedNotice = canWithdraw && missed.length ? "已错过" + missed.map(step => step.age + "岁步骤").join("、") + "，本世无法完成这个项目。可退出项目；普通帮工、休息和人生事件仍照常进行。" : "";
    return {
      id: ID, title: "建立固定客源", label: "建立固定客源", status, statusLabel,
      visible: true, canAccept: !reason, acceptReason: reason,
      offer: { available: !reason, reason }, accept: { available: !reason, reason },
      withdraw: { available: canWithdraw, reason: canWithdraw ? "已付成本不返还，工资与成长保留" : "没有正在进行的项目" },
      definition: { id: ID, title: "建立固定客源", startAge: 19, deadlineAge: 28, minimumCraft: 5, requiredActionPoints: 5, totalActionPoints: 8 },
      summary: missedNotice || "用两次真实帮工和一次准备，逐步让熟客愿意直接找你维修。普通帮工始终可以继续。",
      canWithdraw, deadlineAge: 28, remainingNodes,
      remaining: { nodes: remainingNodes, steps: steps.filter(step => !step.completed).map(step => step.id) },
      progress: { current: completeCount, total: STEPS.length },
      steps, craft: { current: life.skills.craft, target: 5 },
      next: project && project.status !== "active" ? outcomes[project.status] : missedNotice || (next ? next.label : "28岁完成人生事件后，按实际步骤和手艺5结算"),
      investment: { actionPoints: prep ? prep.ap : 0, money: prep ? prep.moneySpent : 0, energy: prep ? prep.energySpent : 0 },
      costs: ["接受和退出均为0行动点，无额外奖励", "19岁与24岁的工作各2行动点，工资各结算一次", "21岁准备任选其一：练习1行动点与2精力；购买工具1行动点与" + toolkit.price + "元", "青年共8行动点，必要步骤共5点，其余3点自定"],
      alternatives: "不接受项目也可照常帮工。普通帮工收入7、耗2精力、压力+1，并有基础手艺与修理铺成长。",
      outcomes,
      outcome: project && project.resultId ? { id: project.resultId, status, label: statusLabel, detail: outcomes[status] } : null,
      npcReply: project && project.resultId ? outcomes[status] : missedNotice || (completeCount === 3 ? "这些年你交代的活，大家都记得。等28岁那页事情落定，再看看能否独立接下熟客。" : completeCount ? "你做过的那次帮工已经记下，下一步照自己的生活安排来。" : "帮工有眼前的工钱。若想以后独立接活，就得腾出一点时间准备。"),
      resultId: project && project.resultId || null,
      unlock: { jobId: JOB_ID, unlocked: isUnlocked(life), minAge: 30 },
    };
  }

  global.EchoTownProjects = Object.freeze({ VERSION: 1, ID, JOB_ID, accept, withdraw, record, settle, getView, normalize, isUnlocked, getJobDefinition });
})(window);
