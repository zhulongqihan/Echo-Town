(function (global) {
  "use strict";
  const engine = global.EchoTownEngine;
  const save = global.EchoTownSave;
  const audio = global.EchoTownAudio;
  const defaults = engine.getState();
  const loaded = save.load({ defaultState: defaults });
  if (loaded.ok && loaded.state) {
    try { loaded.state = engine.normalizeState(loaded.state); }
    catch (error) { loaded.ok = false; loaded.recoveryRequired = true; loaded.message = "本地存档无法安全恢复，原档已保护。请导入有效备份。"; }
  }
  if (loaded.ok && loaded.state) {
    let ready = loaded;
    if (loaded.migrated) ready = save.commitImport(loaded, null, { startupMigration: true });
    if (ready.ok) engine.replaceState(ready.state);
    else {
      defaults.notice = "旧存档仍保留。迁移未能写入，请先释放存储空间或导出旧备份后重新导入。";
      engine.replaceState(defaults);
      engine.setRecoveryRequired(true);
    }
  } else if (!loaded.ok) {
    defaults.notice = loaded.message || "本地存档暂时无法读取，请导入有效备份。";
    engine.replaceState(defaults);
    if (loaded.recoveryRequired || loaded.code === "STORAGE_READ_FAILED") engine.setRecoveryRequired(true);
  }
  audio?.setVolume(engine.getState().settings.volume);
  global.EchoTown = { content: global.EchoTownContent, strategy: global.EchoTownStrategy, engine, save, audio, ui: global.EchoTownUI };
  global.EchoTownUI.bind();
  global.EchoTownUI.render();
  if ("serviceWorker" in navigator && global.location.protocol !== "file:") {
    let waiting = null;
    let reloading = false;
    const announce = (registration) => {
      if (registration.waiting && navigator.serviceWorker.controller) {
        waiting = registration.waiting;
        global.dispatchEvent(new CustomEvent("echo-town-update-ready"));
      }
    };
    navigator.serviceWorker.register("sw.js").then((registration) => {
      announce(registration);
      registration.addEventListener("updatefound", () => {
        const worker = registration.installing;
        worker?.addEventListener("statechange", () => { if (worker.state === "installed") announce(registration); });
      });
    }).catch(() => {});
    global.addEventListener("echo-town-apply-update", () => {
      if (!waiting) return;
      const saved = save.persist(engine.getState());
      if (!saved.ok) { global.EchoTownUI.showToast("保存失败，请先导出备份，暂不更新"); return; }
      reloading = true;
      waiting.postMessage({ type: "SKIP_WAITING" });
    });
    navigator.serviceWorker.addEventListener("controllerchange", () => { if (reloading) global.location.reload(); });
  }
})(window);
