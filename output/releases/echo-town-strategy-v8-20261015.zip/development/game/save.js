(function (global) {
  "use strict";

  const CONTRACT = Object.freeze({
    storageKey: "echo-town-generation-save-v8",
    previousStorageKey: "echo-town-generation-save",
    backupKey: "echo-town-generation-save-v8-before-import",
    v7BackupPrefix: "echo-town-generation-save-v7-original-",
    legacyStorageKeys: Object.freeze([
      "echo-town-generation-save-v6", "echo-town-generation-save-v5",
      "echo-town-generation-save-v4", "echo-town-save", "echo-town-mvp-v1",
    ]),
    version: 8,
    acceptedVersions: Object.freeze([7, 8]),
    maxBytes: 512 * 1024,
    maxInputBytes: 2 * 1024 * 1024,
  });
  const RESOURCE_KEYS = ["money", "energy", "health", "happiness", "pressure", "expectation"];
  const SKILL_KEYS = ["study", "craft", "expression", "empathy", "courage"];
  const RELATIONSHIP_KEYS = ["family", "mentor", "friend", "partner", "child", "neighbor"];
  const TOWN_KEYS = ["shop", "bridge", "school", "market", "archive"];
  const GOAL_KEYS = ["learn", "home", "connection", "town", "record", "free"];
  const ROUND_AGES = [6, 8, 10, 11, 13, 15, 17, 19, 21, 24, 28, 32, 36, 40, 44, 47, 49, 52, 56, 60, 65, 70, 75];
  const CLEARED_MARKER = '{"version":8,"cleared":true}';
  const ROUTES = ["craft", "study", "community"];
  const STAGES = ["childhood", "adolescence", "youth", "middle", "later"];

  function isRecord(value) {
    return value !== null && typeof value === "object" && !Array.isArray(value);
  }

  function clone(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function error(code, message, path) {
    const result = new Error(message);
    result.code = code;
    if (path) result.path = path;
    return result;
  }

  function failure(caught, fallback = "INVALID_SAVE") {
    return {
      ok: false,
      code: caught.code || fallback,
      message: caught.code ? caught.message : "存档结构不完整或状态不一致",
      ...(caught.path ? { path: caught.path } : {}),
    };
  }

  function requireValue(condition, path) {
    if (!condition) throw error("INVALID_SAVE", "存档结构不完整或状态不一致", path);
  }

  function number(value, path, minimum = 0, maximum = Number.MAX_SAFE_INTEGER, integer = false) {
    requireValue(typeof value === "number" && Number.isFinite(value) && value >= minimum && value <= maximum && (!integer || Number.isInteger(value)), path);
  }

  function string(value, path) {
    requireValue(typeof value === "string", path);
  }

  function list(value, path, maximum, check = string) {
    requireValue(Array.isArray(value) && value.length <= maximum, path);
    value.forEach((item, index) => check(item, `${path}[${index}]`));
  }

  function numericMap(value, keys, path) {
    requireValue(isRecord(value), path);
    keys.forEach((key) => number(value[key], `${path}.${key}`));
    Object.entries(value).forEach(([key, amount]) => number(amount, `${path}.${key}`));
  }

  function optionalList(value, key, path, maximum, check = string) {
    if (value[key] !== undefined) list(value[key], `${path}.${key}`, maximum, check);
  }

  function actionEntry(entry, path) {
    requireValue(isRecord(entry), path);
    number(entry.round, `${path}.round`, 1, 23, true);
    number(entry.age, `${path}.age`, 1, 120, true);
    string(entry.label, `${path}.label`);
    string(entry.result, `${path}.result`);
    if (entry.success !== undefined) requireValue(typeof entry.success === "boolean", `${path}.success`);
  }

  function logEntry(entry, path) {
    requireValue(isRecord(entry), path);
    number(entry.age, `${path}.age`, 1, 120, true);
    ["label", "result", "kind"].forEach((key) => string(entry[key], `${path}.${key}`));
  }

  function opportunityEntry(entry, path) {
    requireValue(isRecord(entry), path);
    number(entry.age, `${path}.age`, 1, 120, true);
    string(entry.id, `${path}.id`);
    string(entry.label, `${path}.label`);
  }

  function milestoneEntry(entry, path) {
    requireValue(isRecord(entry), path);
    string(entry.goalId, `${path}.goalId`);
    string(entry.label, `${path}.label`);
    if (entry.detail !== undefined) string(entry.detail, `${path}.detail`);
  }

  function feedback(value, path, eventFeedback = false) {
    if (value === null || value === undefined) return;
    requireValue(isRecord(value), path);
    string(value.title, `${path}.title`);
    list(value.changes, `${path}.changes`, 100);
    if (eventFeedback) {
      ["actionId", "result", "future"].forEach((key) => string(value[key], `${path}.${key}`));
      list(value.newLevels, `${path}.newLevels`, 100);
      list(value.newSecrets, `${path}.newSecrets`, 100);
      if (value.test !== null && value.test !== undefined) {
        requireValue(isRecord(value.test), `${path}.test`);
        requireValue(typeof value.test.success === "boolean", `${path}.test.success`);
        string(value.test.label, `${path}.test.label`);
        ["score", "difficulty", "roll"].forEach((key) => number(value.test[key], `${path}.test.${key}`, -Number.MAX_SAFE_INTEGER));
      }
      if (value.stageBreak !== null && value.stageBreak !== undefined) {
        requireValue(isRecord(value.stageBreak), `${path}.stageBreak`);
        ["label", "range", "hint"].forEach((key) => string(value.stageBreak[key], `${path}.stageBreak.${key}`));
      }
    } else {
      string(value.copy, `${path}.copy`);
    }
    ["newItems", "newSecrets", "newMoments", "tags"].forEach((key) => optionalList(value, key, path, 100));
    optionalList(value, "milestones", path, 100, milestoneEntry);
  }

  function validateLedger(ledger, path, historical = false) {
    requireValue(isRecord(ledger), path);
    numericMap(ledger.opening, ["money", "debt", "income", "expenses"], `${path}.opening`);
    numericMap(ledger.totals, ["income", "expenses", "borrowed", "repaid", "unpaid"], `${path}.totals`);
    if (!historical || ledger.entries !== undefined) {
      list(ledger.entries, `${path}.entries`, 4096, (entry, entryPath) => {
        requireValue(isRecord(entry), entryPath);
        number(entry.round, `${entryPath}.round`, 0, 22, true);
        string(entry.id, `${entryPath}.id`);
        string(entry.kind, `${entryPath}.kind`);
        number(entry.money, `${entryPath}.money`, -Number.MAX_SAFE_INTEGER);
        number(entry.debt, `${entryPath}.debt`, -Number.MAX_SAFE_INTEGER);
        number(entry.balance, `${entryPath}.balance`);
      });
    }
  }

  function validateStrategy(strategy, path, historical = false, currentRound = 22) {
    requireValue(isRecord(strategy), path);
    if (!historical || strategy.version !== undefined) requireValue(strategy.version === 1, `${path}.version`);
    requireValue(ROUTES.includes(strategy.routeId), `${path}.routeId`);
    requireValue(isRecord(strategy.goals) && Object.keys(strategy.goals).length <= 15, `${path}.goals`);
    Object.entries(strategy.goals).forEach(([key, goal]) => {
      const goalPath = `${path}.goals.${key}`;
      const parts = key.split(":");
      requireValue(parts.length === 2 && ROUTES.includes(parts[0]) && STAGES.includes(parts[1]), goalPath);
      requireValue(isRecord(goal) && ["achieved", "missed", "legacy-settled"].includes(goal.status), goalPath);
      number(goal.round, `${goalPath}.round`, 0, currentRound, true);
      if (goal.id !== undefined) requireValue(goal.id === key, `${goalPath}.id`);
      if (goal.routeId !== undefined) requireValue(goal.routeId === parts[0], `${goalPath}.routeId`);
      if (goal.stageId !== undefined) requireValue(goal.stageId === parts[1], `${goalPath}.stageId`);
      optionalList(goal, "checks", goalPath, 4, (value, itemPath) => requireValue(typeof value === "boolean", itemPath));
      optionalList(goal, "conditions", goalPath, 4, (condition, itemPath) => {
        requireValue(isRecord(condition), itemPath);
        string(condition.label, `${itemPath}.label`);
        requireValue(typeof condition.met === "boolean", `${itemPath}.met`);
      });
    });
    if (!historical || strategy.evidence !== undefined) {
      const seen = new Set();
      list(strategy.evidence, `${path}.evidence`, 256, (entry, entryPath) => {
        requireValue(isRecord(entry), entryPath);
        string(entry.id, `${entryPath}.id`);
        requireValue(["event", "job", "life", "opportunity"].includes(entry.kind), `${entryPath}.kind`);
        number(entry.round, `${entryPath}.round`, 0, currentRound, true);
        requireValue(typeof entry.success === "boolean", `${entryPath}.success`);
        const key = JSON.stringify([entry.round, entry.kind, entry.id]);
        requireValue(!seen.has(key), entryPath);
        seen.add(key);
      });
    }
    const consequences = new Set();
    list(strategy.consequences, `${path}.consequences`, 3, (entry, entryPath) => {
      requireValue(isRecord(entry), entryPath);
      string(entry.id, `${entryPath}.id`);
      number(entry.round, `${entryPath}.round`, 0, currentRound, true);
      requireValue(typeof entry.success === "boolean", `${entryPath}.success`);
      ["label", "copy", "chainId", "sourceActionId"].forEach((key) => { if (entry[key] !== undefined) string(entry[key], `${entryPath}.${key}`); });
      if (entry.routeId !== undefined) requireValue(ROUTES.includes(entry.routeId), `${entryPath}.routeId`);
      if (entry.age !== undefined) number(entry.age, `${entryPath}.age`, 1, 120, true);
      requireValue(!consequences.has(entry.id), entryPath);
      consequences.add(entry.id);
    });
    if (!historical || strategy.migratedThroughStage !== undefined) {
      requireValue(strategy.migratedThroughStage === null || STAGES.includes(strategy.migratedThroughStage), `${path}.migratedThroughStage`);
    }
  }

  function historyEntry(entry, path) {
    requireValue(isRecord(entry), path);
    number(entry.generation, `${path}.generation`, 1, Number.MAX_SAFE_INTEGER, true);
    number(entry.age, `${path}.age`, 1, 120, true);
    ["profileId", "talentId", "goalId", "outcomeTitle", "outcomeCopy", "bestSkill"].forEach((key) => string(entry[key], `${path}.${key}`));
    number(entry.goalProgress, `${path}.goalProgress`);
    number(entry.goalTarget, `${path}.goalTarget`, 1);
    if (entry.cashflow !== undefined) numericMap(entry.cashflow, ["income", "expenses", "debt"], `${path}.cashflow`);
    ["talentIds", "routeTags", "inventory", "legacyIds", "achievementIds", "secretIds", "momentIds", "jobHistory"].forEach((key) => optionalList(entry, key, path, 100));
    optionalList(entry, "actions", path, 23, actionEntry);
    optionalList(entry, "lifeLog", path, 120, logEntry);
    optionalList(entry, "opportunityHistory", path, 23, opportunityEntry);
    if (entry.ledger !== undefined) validateLedger(entry.ledger, `${path}.ledger`, true);
    if (entry.strategy !== undefined) validateStrategy(entry.strategy, `${path}.strategy`, true);
  }

  function validateLife(life, saved) {
    const path = "currentLife";
    requireValue(isRecord(life), path);
    requireValue(["active", "complete"].includes(life.status), `${path}.status`);
    number(life.generation, `${path}.generation`, 1, Number.MAX_SAFE_INTEGER, true);
    number(life.round, `${path}.round`, 0, 22, true);
    number(life.age, `${path}.age`, 1, 120, true);
    requireValue(life.age === ROUND_AGES[life.round], `${path}.age`);
    number(life.seed, `${path}.seed`, 0, 4294967295, true);
    ["profileId", "talentId", "goalId", "jobId"].forEach((key) => string(life[key], `${path}.${key}`));
    numericMap(life.resources, RESOURCE_KEYS, `${path}.resources`);
    numericMap(life.skills, SKILL_KEYS, `${path}.skills`);
    numericMap(life.relationships, RELATIONSHIP_KEYS, `${path}.relationships`);
    numericMap(life.town, TOWN_KEYS, `${path}.town`);
    numericMap(life.progress, GOAL_KEYS, `${path}.progress`);
    numericMap(life.cashflow, ["income", "expenses", "debt"], `${path}.cashflow`);
    numericMap(life.maxResources, ["energy"], `${path}.maxResources`);
    number(life.actionPoints, `${path}.actionPoints`, 0, 2, true);
    ["sideActionsUsed", "jobShifts"].forEach((key) => number(life[key], `${path}.${key}`, 0, Number.MAX_SAFE_INTEGER, true));
    const listLimits = {
      inventory: 100, jobHistory: 100, sceneVisits: 80, flags: 80, secrets: 100,
      inheritedLegacyIds: 3, legacyCandidates: 20, selectedLegacies: 3,
      newAchievements: 100, newSecrets: 100, moments: 100, newMoments: 100,
    };
    Object.entries(listLimits).forEach(([key, maximum]) => list(life[key], `${path}.${key}`, maximum));
    list(life.actions, `${path}.actions`, 23, actionEntry);
    list(life.lifeLog, `${path}.lifeLog`, 120, logEntry);
    feedback(life.lastAction, `${path}.lastAction`, true);
    ["lifeFeedback", "sceneFeedback", "opportunityFeedback"].forEach((key) => feedback(life[key], `${path}.${key}`));
    if (life.carryForward !== null && life.carryForward !== undefined) {
      requireValue(isRecord(life.carryForward), `${path}.carryForward`);
      string(life.carryForward.title, `${path}.carryForward.title`);
      string(life.carryForward.copy, `${path}.carryForward.copy`);
      number(life.carryForward.age, `${path}.carryForward.age`, 1, 120, true);
    }
    const opportunity = life.opportunity;
    requireValue(isRecord(opportunity), `${path}.opportunity`);
    list(opportunity.drawnIds, `${path}.opportunity.drawnIds`, 3);
    requireValue(new Set(opportunity.drawnIds).size === opportunity.drawnIds.length, `${path}.opportunity.drawnIds`);
    requireValue(typeof opportunity.skipped === "boolean", `${path}.opportunity.skipped`);
    requireValue(opportunity.selectedId === null || typeof opportunity.selectedId === "string", `${path}.opportunity.selectedId`);
    if (opportunity.selectedId !== null) requireValue(opportunity.drawnIds.includes(opportunity.selectedId) && !opportunity.skipped, `${path}.opportunity.selectedId`);
    list(opportunity.history, `${path}.opportunity.history`, 23, opportunityEntry);
    const resolved = opportunity.selectedId !== null || opportunity.skipped;
    if (!resolved) requireValue(opportunity.drawnIds.length > 0 && !life.lastAction && life.actionPoints === 2, `${path}.opportunity`);
    if (life.lastAction) {
      const latest = life.actions[life.actions.length - 1];
      requireValue(resolved && Boolean(latest) && latest.round === life.round + 1 && latest.age === life.age, `${path}.lastAction`);
    }
    {
      requireValue(isRecord(life.build), `${path}.build`);
      numericMap(life.build.attributes, ["appearance", "intelligence", "physique", "family"], `${path}.build.attributes`);
      numericMap(life.build.interests, [], `${path}.build.interests`);
      list(life.build.talentIds, `${path}.build.talentIds`, 3);
      list(life.build.routeTags, `${path}.build.routeTags`, 100);
    }
    if (life.characters !== undefined) numericMap(life.characters, [], `${path}.characters`);
    if (life.strategy !== undefined) {
      validateStrategy(life.strategy, `${path}.strategy`, false, life.round);
      if (typeof global.EchoTownStrategy?.initLife === "function") {
        const canonical = global.EchoTownStrategy.initLife(clone(life));
        for (const [key, fields] of [["evidence", ["id", "kind", "round", "success"]], ["consequences", ["id", "round", "success"]]]) {
          const project = (entries) => entries.map((entry) => fields.map((field) => entry[field]));
          requireValue(JSON.stringify(project(life.strategy[key])) === JSON.stringify(project(canonical[key])), `${path}.strategy.${key}`);
        }
      }
    }
    if (life.ledger !== undefined) validateLedger(life.ledger, `${path}.ledger`);
    if (life.migration !== undefined) {
      requireValue(isRecord(life.migration) && life.migration.fromVersion === 7, `${path}.migration`);
      number(life.migration.round, `${path}.migration.round`, 0, 22, true);
      requireValue(STAGES.includes(life.migration.stageId) && life.migration.stageId === stageForRound(life.migration.round), `${path}.migration.stageId`);
      requireValue(typeof life.migration.deferGoals === "boolean", `${path}.migration.deferGoals`);
      if (life.migration.goalAccessVersion !== undefined) {
        requireValue(life.migration.goalAccessVersion === 1, `${path}.migration.goalAccessVersion`);
        list(life.migration.activeGoalIds, `${path}.migration.activeGoalIds`, 3, (id, itemPath) => {
          requireValue(ROUTES.some(routeId => id === routeId + ":" + life.migration.stageId), itemPath);
        });
        requireValue(new Set(life.migration.activeGoalIds).size === life.migration.activeGoalIds.length, `${path}.migration.activeGoalIds`);
      }
      numericMap(life.migration.legacyGoalProgress, GOAL_KEYS, `${path}.migration.legacyGoalProgress`);
    }
    if (life.status === "complete") {
      requireValue(saved.screen !== "game", "screen");
      requireValue(isRecord(life.outcome), `${path}.outcome`);
      ["title", "copy", "tone"].forEach((key) => string(life.outcome[key], `${path}.outcome.${key}`));
      number(life.outcome.score, `${path}.outcome.score`, -Number.MAX_SAFE_INTEGER);
      optionalList(life.outcome, "consequences", `${path}.outcome`, 100, (item, itemPath) => {
        if (typeof item === "string") return;
        requireValue(isRecord(item), itemPath);
        ["label", "detail", "copy"].forEach((key) => { if (item[key] !== undefined) string(item[key], `${itemPath}.${key}`); });
      });
      requireValue(life.generation === saved.world.completedLives, `${path}.generation`);
      requireValue(life.selectedLegacies.every((id) => life.legacyCandidates.includes(id)), `${path}.selectedLegacies`);
    } else {
      requireValue(saved.screen !== "ending", "screen");
      requireValue(life.outcome === null, `${path}.outcome`);
      requireValue(life.generation === saved.world.completedLives + 1, `${path}.generation`);
    }
  }

  function validateState(saved, acceptedVersions = CONTRACT.acceptedVersions) {
    try {
      requireValue(isRecord(saved), "state");
      if (!acceptedVersions.includes(saved.version)) throw error("WRONG_VERSION", "需要 v7 或 v8 存档");
      requireValue(isRecord(saved.world), "world");
      number(saved.world.completedLives, "world.completedLives", 0, Number.MAX_SAFE_INTEGER, true);
      numericMap(saved.world.town, TOWN_KEYS, "world.town");
      list(saved.world.history, "world.history", 40, historyEntry);
      ["legacyBank", "collectedLegacyIds", "achievements", "secrets", "moments"].forEach((key) => list(saved.world[key], `world.${key}`, key === "legacyBank" ? 3 : 100));
      numericMap(saved.world.totals, ["choices", "tests", "testWins", "workShifts", "moneyEarned", "moneySpent"], "world.totals");
      requireValue(["start", "game", "ending", "archive"].includes(saved.screen), "screen");
      requireValue(typeof saved.introSeen === "boolean", "introSeen");
      requireValue(isRecord(saved.settings), "settings");
      ["fontScale", "sound"].forEach((key) => requireValue(typeof saved.settings[key] === "boolean", `settings.${key}`));
      if (saved.settings.volume !== undefined) number(saved.settings.volume, "settings.volume", 0, 1);
      if (saved.notice !== undefined) string(saved.notice, "notice");
      if (saved.setup !== undefined) {
        const setup = saved.setup;
        requireValue(isRecord(setup), "setup");
        ["profileId", "talentId", "goalId"].forEach((key) => string(setup[key], `setup.${key}`));
        requireValue(ROUTES.includes(setup.routeId), "setup.routeId");
        list(setup.talentIds, "setup.talentIds", 3);
        requireValue(new Set(setup.talentIds).size === setup.talentIds.length, "setup.talentIds");
        numericMap(setup.attributes, ["appearance", "intelligence", "physique", "family"], "setup.attributes");
        Object.values(setup.attributes).forEach((value) => number(value, "setup.attributes", 0, 10, true));
        requireValue(Object.values(setup.attributes).reduce((sum, value) => sum + value, 0) <= 20, "setup.attributes");
      }
      if (saved.currentLife === null) requireValue(!["game", "ending"].includes(saved.screen), "screen");
      else validateLife(saved.currentLife, saved);
      return { ok: true };
    } catch (caught) {
      return failure(caught);
    }
  }

  function byteLength(value) {
    if (typeof global.TextEncoder === "function") return new global.TextEncoder().encode(value).length;
    if (typeof global.Blob === "function") return new global.Blob([value]).size;
    let bytes = 0;
    for (const character of value) {
      const point = character.codePointAt(0);
      bytes += point <= 0x7f ? 1 : point <= 0x7ff ? 2 : point <= 0xffff ? 3 : 4;
    }
    return bytes;
  }

  // Compact JSON is the sole persistent/export wire format. Do not add timestamps
  // by default: the same state must fit the same size limit on every round trip.
  function serialize(state, options = {}) {
    const payload = options.includeTimestamp === true ? { ...clone(state), exportedAt: new Date().toISOString() } : state;
    const text = JSON.stringify(payload);
    if (typeof text !== "string") throw error("INVALID_SAVE", "没有可导出的存档");
    if (byteLength(text) > CONTRACT.maxBytes) throw error("SAVE_TOO_LARGE", "有效存档超过 512 KiB，请先导出已有备份");
    return text;
  }

  function stageForRound(round) {
    return global.EchoTownContent?.rounds?.[round]?.stage || (round < 4 ? "childhood" : round < 7 ? "adolescence" : round < 11 ? "youth" : round < 17 ? "middle" : "later");
  }

  // Migration is additive. No normalization, truncation, rule replay or regrading.
  function migrateV7ToV8(saved) {
    const validated = validateState(saved);
    if (!validated.ok) throw error(validated.code, validated.message, validated.path);
    const migrated = clone(saved);
    migrated.version = CONTRACT.version;
    if (migrated.settings.volume === undefined) migrated.settings.volume = 0.6;
    if (saved.version === 7 && migrated.currentLife) {
      const life = migrated.currentLife;
      life.migration = {
        fromVersion: 7,
        round: life.round,
        stageId: stageForRound(life.round),
        deferGoals: true,
        legacyGoalProgress: clone(life.progress),
      };
    }
    return migrated;
  }

  // options.normalize is accepted for call-site compatibility, but deliberately
  // not executed: the old normalizer discards v8 fields and rewrites v7 history.
  function prepareImport(text, options = {}) {
    void options;
    if (typeof text !== "string") return { ok: false, code: "INVALID_JSON", message: "存档不是有效 JSON" };
    if (byteLength(text) > CONTRACT.maxInputBytes) return { ok: false, code: "INPUT_TOO_LARGE", message: "导入文件超过 2 MiB" };
    let imported;
    try {
      imported = JSON.parse(text);
    } catch (caught) {
      return { ok: false, code: "INVALID_JSON", message: "存档不是有效 JSON" };
    }
    const validated = validateState(imported);
    if (!validated.ok) return validated;
    try {
      const state = migrateV7ToV8(imported);
      const payload = serialize(state);
      return { ok: true, state, payload, sourceVersion: imported.version, migrated: imported.version === 7, rawSource: text };
    } catch (caught) {
      return failure(caught);
    }
  }

  function getStorage(options) {
    if (Object.prototype.hasOwnProperty.call(options, "storage")) return options.storage;
    try { return global.localStorage || null; } catch (caught) { return null; }
  }

  // Read-only. The composition root installs state and explicitly commits v7
  // migration. A corrupt v8 must never silently fall back to an older v7.
  function load(options = {}) {
    const storage = getStorage(options);
    if (!storage) return { ok: false, code: "STORAGE_UNAVAILABLE", message: "本地存档不可用，请及时导出备份" };
    try {
      let cleared = false;
      for (const [sourceKey, expectedVersion] of [[CONTRACT.storageKey, 8], [CONTRACT.previousStorageKey, 7]]) {
        const raw = storage.getItem(sourceKey);
        if (raw === null || raw === undefined) continue;
        if (sourceKey === CONTRACT.storageKey && raw === CLEARED_MARKER) { cleared = true; break; }
        const result = prepareImport(raw);
        if (!result.ok) return { ...result, sourceKey, rawSource: raw, recoveryRequired: true };
        if (result.sourceVersion !== expectedVersion) return { ok: false, code: "WRONG_STORAGE_VERSION", message: "本地存档版本与存储位置不一致，原档已保留", sourceKey, rawSource: raw, recoveryRequired: true };
        return { ...result, sourceKey, needsCommit: expectedVersion === 7 };
      }
      const state = options.defaultState === undefined ? null : clone(options.defaultState);
      if (state) {
        const validated = validateState(state, [8]);
        if (!validated.ok) return validated;
        if (state.settings.volume === undefined) state.settings.volume = 0.6;
      }
      const legacyFound = CONTRACT.legacyStorageKeys.some((key) => storage.getItem(key) !== null);
      return { ok: true, state, empty: true, cleared, needsCommit: false, sourceKey: null, ...(legacyFound ? { message: "检测到更早版本存档，原档仍被保留" } : {}) };
    } catch (caught) {
      return { ok: false, code: "STORAGE_READ_FAILED", message: "本地存档读取失败，原档未改动" };
    }
  }

  function rawBackupKey(storage, rawSource) {
    let hash = 2166136261;
    for (let index = 0; index < rawSource.length; index += 1) hash = Math.imul(hash ^ rawSource.charCodeAt(index), 16777619);
    const prefix = `${CONTRACT.v7BackupPrefix}${(hash >>> 0).toString(16)}-${byteLength(rawSource)}`;
    let key = prefix;
    let suffix = 0;
    let existing = storage.getItem(key);
    while (existing !== null && existing !== undefined && existing !== rawSource) {
      key = `${prefix}-${++suffix}`;
      existing = storage.getItem(key);
    }
    return key;
  }

  // localStorage.setItem is the commit point. All validation and backup writes
  // happen first; only the caller may replace its current in-memory state.
  function commitImport(prepared, currentState, options = {}) {
    const storage = getStorage(options);
    if (!storage) return { ok: false, code: "STORAGE_UNAVAILABLE", message: "本地存档不可用，当前进度未改变" };
    if (!prepared?.ok) return { ok: false, code: "INVALID_PREPARED_SAVE", message: "导入内容尚未通过校验" };
    const validated = validateState(prepared.state, [8]);
    if (!validated.ok) return validated;
    let state;
    let payload;
    let backupPayload;
    try {
      state = clone(prepared.state);
      payload = serialize(state);
      if (!options.startupMigration) {
        const currentValidated = validateState(currentState);
        if (!currentValidated.ok) return { ...currentValidated, code: "BACKUP_INVALID", message: "当前进度无法备份，导入未提交" };
        backupPayload = serialize(currentState);
      }
    } catch (caught) {
      return failure(caught);
    }
    let sourceBackupKey = null;
    try {
      if (options.startupMigration) {
        const active = storage.getItem(CONTRACT.storageKey);
        requireValue(prepared.sourceVersion === 7 && prepared.sourceKey === CONTRACT.previousStorageKey && typeof prepared.rawSource === "string", "startupMigration");
        if ((active !== null && active !== undefined) || storage.getItem(CONTRACT.previousStorageKey) !== prepared.rawSource) {
          return { ok: false, code: "STORAGE_CHANGED", message: "本地进度已经变化，请重新读取后再迁移" };
        }
      } else {
        // Preserve the latest caller memory, which may be newer than its disk save.
        storage.setItem(CONTRACT.backupKey, backupPayload);
        if (prepared.sourceVersion === 7) {
          requireValue(typeof prepared.rawSource === "string", "rawSource");
          sourceBackupKey = rawBackupKey(storage, prepared.rawSource);
          if (storage.getItem(sourceBackupKey) !== prepared.rawSource) storage.setItem(sourceBackupKey, prepared.rawSource);
        }
      }
    } catch (caught) {
      return { ok: false, code: "BACKUP_WRITE_FAILED", message: "备份未能保存，当前进度未改变" };
    }
    try {
      storage.setItem(CONTRACT.storageKey, payload);
    } catch (caught) {
      return { ok: false, code: "STORAGE_WRITE_FAILED", message: "导入未能保存，当前进度未改变" };
    }
    return { ok: true, state, payload, sourceBackupKey, message: options.message || "已导入并保存" };
  }

  function persist(state, options = {}) {
    const storage = getStorage(options);
    if (!storage) return { ok: false, code: "STORAGE_UNAVAILABLE", message: "本地存档不可用" };
    const validated = validateState(state, [8]);
    if (!validated.ok) return validated;
    try {
      const existing = storage.getItem(CONTRACT.storageKey);
      if (existing !== null && existing !== undefined && existing !== CLEARED_MARKER) {
        const current = prepareImport(existing);
        if (!current.ok || current.sourceVersion !== 8) return { ok: false, code: "RECOVERY_REQUIRED", message: "原存档已保护，请先导入有效备份或明确清除进度" };
      }
      const payload = serialize(state);
      storage.setItem(CONTRACT.storageKey, payload);
      return { ok: true, payload, message: options.message || "已保存" };
    } catch (caught) {
      return caught.code ? failure(caught) : { ok: false, code: "STORAGE_WRITE_FAILED", message: "本地保存失败" };
    }
  }

  // The marker prevents the next startup from resurrecting the preserved v7.
  // One atomic write also lets callers reset memory only after success.
  function remove(options = {}) {
    const storage = getStorage(options);
    if (!storage) return { ok: false, code: "STORAGE_UNAVAILABLE", message: "本地存档不可用" };
    try {
      storage.setItem(CONTRACT.storageKey, CLEARED_MARKER);
      return { ok: true };
    } catch (caught) {
      return { ok: false, code: "STORAGE_WRITE_FAILED", message: "清除失败，原档仍被保留" };
    }
  }

  global.EchoTownSave = {
    CONTRACT, clone, byteLength, serialize, validateState, migrateV7ToV8,
    prepareImport, commitImport, load, persist, parse: prepareImport,
    import: prepareImport, remove,
  };
})(window);
